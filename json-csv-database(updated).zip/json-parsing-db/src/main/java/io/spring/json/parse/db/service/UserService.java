package io.spring.json.parse.db.service;

import java.util.Arrays;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import io.spring.json.parse.db.dto.User;
import io.spring.json.parse.db.entities.UserEntity;
import io.spring.json.parse.db.repositories.UserRepository;

@Service
public class UserService {

	@Autowired
	private UserRepository userRepository;

	private static final String API_URL = "https://jsonplaceholder.typicode.com/comments";

	private RestTemplate restTemplate;

	public UserService(RestTemplate restTemplate) {
		this.restTemplate = restTemplate;

	}

	public List<User> getUserFromApi() {

		ResponseEntity<User[]> response = restTemplate.getForEntity(API_URL, User[].class);
		return Arrays.asList(response.getBody());

	}

	public void saveUserToDatabase(List<User> users) {
		for (User user : users) {
			UserEntity userEntity = new UserEntity();

			userEntity.setPostId(user.getPostId());
			userEntity.setId(user.getId());
			userEntity.setName(user.getName());
			userEntity.setEmail(user.getEmail());
			userEntity.setBody(user.getBody());

			userRepository.save(userEntity);
		}

	}
}
